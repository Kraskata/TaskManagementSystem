﻿namespace TaskManagementSystem.Core.Models.Home
{
    public class IndexViewModel
    {
    }
}
