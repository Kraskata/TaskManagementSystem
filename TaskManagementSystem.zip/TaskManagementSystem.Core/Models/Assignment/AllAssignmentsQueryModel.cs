﻿namespace TaskManagementSystem.Core.Models.Assignment
{
    public class AllAssignmentsQueryModel
    {
    }
}
