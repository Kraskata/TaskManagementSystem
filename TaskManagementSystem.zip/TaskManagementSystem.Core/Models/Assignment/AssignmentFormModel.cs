﻿namespace TaskManagementSystem.Core.Models.Assignment
{
    public class AssignmentFormModel
    {
    }
}
