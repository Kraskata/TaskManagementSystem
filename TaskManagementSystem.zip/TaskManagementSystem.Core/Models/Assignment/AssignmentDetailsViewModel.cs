﻿namespace TaskManagementSystem.Core.Models.Assignment
{
    public class AssignmentDetailsViewModel
    {
    }
}
