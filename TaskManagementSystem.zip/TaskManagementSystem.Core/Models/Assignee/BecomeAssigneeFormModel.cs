﻿namespace TaskManagementSystem.Core.Models.Assignee
{
    public class BecomeAssigneeFormModel
    {
    }
}
